Featherly command-line tool
========================

Featherly Pro is required. Open Featherly, unlock Pro, and launch the app once
so it can create the local Pro license token. No account or network connection
is used by this tool.

INSTALL
-------
1. Copy `featherly` from the Featherly DMG or CLI ZIP to your Downloads folder.
2. Run:

   sudo install -m 755 ~/Downloads/featherly /usr/local/bin/featherly

3. Check the license:

   featherly license

USAGE
-----
  featherly compress <file-or-folder> ... [options]
  featherly batch <folder> ... [options]
  featherly license
  featherly --help

OPTIONS
  --out <folder>       Output folder (required for folders/multiple inputs)
  --format <type>      jpeg | png | heic | webp (default: jpeg)
  --quality <1-100>    JPEG/HEIC/WebP quality (default: 70)
  --max <pixels>       Limit the longest side; never upscales
  --suffix <text>      Filename suffix (default: -featherly)
  --overwrite          Replace an existing output file
  --json               Print machine-readable results
  --quiet              Only print errors
  --license <path>     Use a specific Pro license token

EXAMPLES
--------
  featherly compress ~/Desktop/photo.jpg --quality 72
  featherly batch ~/Pictures/shoot --out ~/Desktop/web --max 1600
  featherly batch ~/Pictures --out ~/Desktop/optimized --format webp --json

The CLI is part of the paid batch export entitlement. It never uploads files.
